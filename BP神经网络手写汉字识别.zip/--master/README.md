# -
BP神经网络mnist手写数字识别Python实现
pycharm创建项目加载文件，解压mnist数据集
文件包括训练集，标签的mat文件可以进行训练。包括训练好的权重以及偏移量，输入图片路径后缀如：4/mnist_test_4.png即可对该图片测试
